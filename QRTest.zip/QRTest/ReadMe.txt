
1. Please open TestWebApiApp.sln from the TestWebApiApp folder.

2. Created a console app to get/read the input file and upload to rqserver.

3. FileController - Created two APIs
� 
- UploadFile - Get file path in URI and upload to qrserver.
� 
- FileUpload- Read the local file path and upload to qrserver.